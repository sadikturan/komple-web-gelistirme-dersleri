export interface Category {
    id: any;
    name: string;
}