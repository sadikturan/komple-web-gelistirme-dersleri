export const environment = {
  production: true,
  adminEmail: "info@cinarturan.com",
  api_key: "AIzaSyDyFVtGZ7hvlhLIO4p8GkleoHU51EFV5EA",
  database_url: "https://ng-shopapp-d4ef5-default-rtdb.firebaseio.com/"
};


// development
// production