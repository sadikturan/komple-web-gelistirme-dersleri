import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  product = {
    id: 1,
    name: "iphone 14",
    price: 20000,
    imageUrl: "1.jpeg",
    description: "iyi telefon",
    isActive: true
  }

  productList= ["iphone 14", "iphone 15", "iphone 16","iphone 17"];

  products:any= [
    {
      id: 1,
      name: "iphone 14",
      price: 20000,
      imageUrl: "1.jpeg",
      description: "iyi telefon",
      isActive: false
    },
    {
      id: 2,
      name: "iphone 15",
      price: 30000,
      imageUrl: "2.jpeg",
      description: "iyi telefon",
      isActive: false
    }
    ,
    {
      id: 2,
      name: "iphone 16",
      price: 30000,
      imageUrl: "3.jpeg",
      description: "iyi telefon",
      isActive: true
    }
  ];

}
